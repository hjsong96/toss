package com.toss.send;

public class AccountsDTO {

	private String aaccount, mphone, abank, aholder, abalance;

	public String getAaccount() {
		return aaccount;
	}

	public void setAaccount(String aaccount) {
		this.aaccount = aaccount;
	}

	public String getMphone() {
		return mphone;
	}

	public void setMphone(String mphone) {
		this.mphone = mphone;
	}

	public String getAbank() {
		return abank;
	}

	public void setAbank(String abank) {
		this.abank = abank;
	}

	public String getAholder() {
		return aholder;
	}

	public void setAholder(String aholder) {
		this.aholder = aholder;
	}

	public String getAbalance() {
		return abalance;
	}

	public void setAbalance(String abalance) {
		this.abalance = abalance;
	}
}
