package com.toss.send;

public class TransactionsDTO {
	int tno, ttoggle;
	String aaccount, tbank, tholder, tdate, thistory, tamount, tbalance, tmemo;
	
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public int getTtoggle() {
		return ttoggle;
	}
	public void setTtoggle(int ttoggle) {
		this.ttoggle = ttoggle;
	}
	public String getAaccount() {
		return aaccount;
	}
	public void setAaccount(String aaccount) {
		this.aaccount = aaccount;
	}
	public String getTbank() {
		return tbank;
	}
	public void setTbank(String tbank) {
		this.tbank = tbank;
	}
	public String getTholder() {
		return tholder;
	}
	public void setTholder(String tholder) {
		this.tholder = tholder;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getThistory() {
		return thistory;
	}
	public void setThistory(String thistory) {
		this.thistory = thistory;
	}
	public String getTamount() {
		return tamount;
	}
	public void setTamount(String tamount) {
		this.tamount = tamount;
	}
	public String getTbalance() {
		return tbalance;
	}
	public void setTbalance(String tbalance) {
		this.tbalance = tbalance;
	}
	public String getTmemo() {
		return tmemo;
	}
	public void setTmemo(String tmemo) {
		this.tmemo = tmemo;
	}

}
